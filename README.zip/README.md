# Eternal Loyalty

## Description

Platform game delevoped for a subject in the career of Programming and Desing in videogmaes - UPC. 

The game is about a dog trying to arrive to his owner.

## Key Features

 - Jumps.
 - Fall into the void.
 - Kind of flying.
 - Go forwards and backwards.
 - Animations.
 - Colliders.
 - Die.
 - Textures.
 
## Controls

 - A to move left.
 - D to move right.
 - SPACE to jump.
 - F1 to go back to start
 - F3 to go back to start
 - F4 to die and trigger die animation.
 - F9 toggle debug.
 - F10 God mode.

## Developers

 - Marc Avante - Programer and developer.
 - Andrea Doña - Art disegner and level designer.
 - Both taking the roll of management.


## License

This project is licensed under an unmodified MIT license, which is an OSI-certified license that allows static linking with closed source software. Check [LICENSE](LICENSE) for further details.

